import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-choose-category',
  templateUrl: './choose-category.component.html',
  styleUrls: ['./choose-category.component.css']
})
export class ChooseCategoryComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }
  onCategoryChange(){
this.router.navigate(['/category/gallery'])
  }

}
