import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-s9',
  templateUrl: './s9.component.html',
  styleUrls: ['./s9.component.css']
})
export class S9Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
